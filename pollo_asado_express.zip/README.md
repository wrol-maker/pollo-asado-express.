# Pollo Asado Express

Sitio web estático para pedidos de pollo asado y acompañamientos. Publicable en **GitHub Pages**.

## Publicación
1. Crea el repo `pollo-asado-express`.
2. Sube `index.html` y carpeta `assets`.
3. Settings → Pages → Source: Deploy from a branch → Branch: main → Folder: /(root).
4. Guarda y visita la URL.

## Personaliza
- Reemplaza imágenes por fotos reales.
- Actualiza tu número de WhatsApp en Contacto.
- Ajusta precios y horarios.

## Nota
Flujo de pago demostrativo solo para fines académicos.
